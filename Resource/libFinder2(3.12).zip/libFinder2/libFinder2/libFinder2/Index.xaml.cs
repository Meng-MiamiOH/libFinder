﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace libFinder2
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class Index : ContentPage
    {
        
        public Index()
        {
            InitializeComponent();
        }

        private void first_Clicked(object sender, EventArgs e)
        {
            map.Source = "firstFloor.jpg";
        }

        private void second_Clicked(object sender, EventArgs e)
        {
            map.Source = "secondFloor.jpg";
        }

        private void third_Clicked(object sender, EventArgs e)
        {
            map.Source = "thirdFloor.jpg";
        }

        private void basement_Clicked(object sender, EventArgs e)
        {
            map.Source = "basement.jpg";
        }

        private async void account_Clicked(object sender, EventArgs e)
        {
            ContentPage add = new Account();
            await Navigation.PushAsync(add, true);
        }

        public static string val;
        //use for seperate each line, splite by ";"
        static string[] array;
        //use for seperate each element in each line splite by ","
        static string[] secondArray;
        // third array, use for seperate range of call numbers by " "
        static string[] thirdArray;
        private void Start_Clicked(object sender, EventArgs e)
        {
            try
            {
                string line = "";
                using (StreamReader sr = new StreamReader("search data example.txt"))
                {
                    line = sr.ReadToEnd();
                    test.Text =  line;
                }
                array = line.Split(';');
            }
            catch (IOException ex)
            {
                test.Text =  ex.Message;
            }

            val = search.Text;

            // seperate user input to two seperate parts
            string topTwoLetter = val.Substring(0, 2);
            string restLetter = val.Substring(2, val.Length - 2);

            // go through search function
            string ShelfName = Search(topTwoLetter, restLetter);

            //print out result
            //Console.Write("Your book is at : " + ShelfName);
            //test.Text = "Your book is at : " + topTwoLetter + restLetter +"\n"  + array.ToString();
            test.Text = "Your book is at : " + ShelfName;
        }

        // search bool from top two letter of call number
        private static string Search(string topTwoLetter, string restLetter)
        {
            for (int i = 0; i < array.Length; i++)
            {
                secondArray = array[i].Split(',');
                for (int j = 4; j < secondArray.Length; j++)
                {
                    //check top two letter of call number is equal to Bookshelf inofrmation or not 
                    if (topTwoLetter.CompareTo(secondArray[j].Substring(0, 2)) == 0)
                    {
                        //check weather the call number is in the correct bookshelf range; 
                        //for example B 0 358 which means this bookshefs has category B from 0 to 358
                        if (secondArray[j].Length > 2)
                        {
                            thirdArray = secondArray[j].Split(' ');
                            double numberTwo = Convert.ToDouble(thirdArray[1]);
                            double numberThree = Convert.ToDouble(thirdArray[2]);
                            double restNumber = Convert.ToDouble(restLetter);
                            if (numberTwo < restNumber && numberThree >= restNumber)
                            {
                                return secondArray[0];
                            }
                        }
                        // if the range only has letter no range; 
                        //for example which means this bookshefs has category BC, BD, BE in the same bookshelf
                        if (secondArray[j].Length == 2)
                        {
                            return secondArray[0];
                        }
                    }
                }
            }
            return "Not Found";
        }
    }
}