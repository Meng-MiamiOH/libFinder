﻿using System;
using System.Collections.Generic;
using System.IO;

namespace ConsoleApp1
{
    class Program
    {
        static string val;
        //use for seperate each line, splite by ";"
        static String[] array;
        //use for seperate each element in each line splite by ","
        static String[] secondArray;
        // third array, use for seperate range of call numbers by " "
        static String[] thirdArray;
        static void Main(string[] args)
        {
            try
            {
                String line = "";
                using (StreamReader sr = new StreamReader("search data example.txt"))
                {
                    line = sr.ReadToEnd();
                    Console.WriteLine(line);
                }
                array = line.Split(";");
            }
            catch(IOException e)
            {
                Console.WriteLine(e.Message);
            }

            // get user input
            Console.WriteLine("Please only enter first part of your call number");
            Console.WriteLine("Enter Call No: ");
            val = Console.ReadLine();

            // seperate user input to two seperate parts
            String topTwoLetter = val.Substring(0, 2);
            String restLetter = val.Substring(2, val.Length - 2);

            // go through search function
            String ShelfName = Search(topTwoLetter, restLetter);

            //print out result
            Console.Write("Your book is at : " + ShelfName);
        }

        // search bool from top two letter of call number
        private static string Search(string topTwoLetter, string restLetter)
        {
            for (int i = 0; i < array.Length; i++)
            {
                secondArray = array[i].Split(",");
                for (int j = 4; j < secondArray.Length; j++)
                {
                    //check top two letter of call number is equal to Bookshelf inofrmation or not 
                    if (topTwoLetter.CompareTo(secondArray[j].Substring(0, 2)) == 0)
                    {
                        //check weather the call number is in the correct bookshelf range; 
                        //for example B 0 358 which means this bookshefs has category B from 0 to 358
                        if (secondArray[j].Length > 2)
                        {
                            thirdArray = secondArray[j].Split(" ");
                            double numberTwo = Convert.ToDouble(thirdArray[1]);
                            double numberThree = Convert.ToDouble(thirdArray[2]);
                            double restNumber = Convert.ToDouble(restLetter);
                            if(numberTwo < restNumber && numberThree>= restNumber)
                            {
                                return secondArray[0];
                            }
                        }
                        // if the range only has letter no range; 
                        //for example which means this bookshefs has category BC, BD, BE in the same bookshelf
                        if (secondArray[j].Length == 2)
                        {
                            return secondArray[0];
                        }
                    }
                }
            }
            return "Not Found";
        }
    }
}
