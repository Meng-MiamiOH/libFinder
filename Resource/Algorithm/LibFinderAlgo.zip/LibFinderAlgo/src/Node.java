import java.util.ArrayList;

public class Node implements Comparable<Node> {
	private double x;
	private double y;
	private double z;
	private ArrayList<String> targetInfo; // one point could has multiple items or no information
	private Node parent;
	private double realCost;
	private double heuristicCost;
	private double estimatedValue;

	public Node(double x, double y, double z) {
		this.x = x;
		this.y = y;
		this.z = z;
		targetInfo = new ArrayList<String>();
		realCost = 0;
		heuristicCost = 0;
		estimatedValue = 0;
		parent = null;
	}
	
	public Node(Node obj) {
		this(obj.x, obj.y, obj.z);
		targetInfo = obj.targetInfo;
		realCost = obj.realCost;
		heuristicCost = obj.heuristicCost;
		estimatedValue = obj.estimatedValue;
		parent = obj.parent;
	}
	
	public double getX() {
		return x;
	}
	
	public double getY() {
		return y;
	}
	
	public double getZ() {
		return z;
	}

	public ArrayList<String> getTargetInfo() {
		return targetInfo;
	}

	public void addTargetInfo(String string) {
		this.targetInfo.add(string);
	}

	public Node getParent() {
		return parent;
	}

	public void setParent(Node parent) {
		this.parent = parent;
	}

	public double getRealCost() {
		return realCost;
	}

	public void setRealCost(double realCost) {
		this.realCost = realCost;
	}

	public double getHeuristicCost() {
		return heuristicCost;
	}

	public void setHeuristicCost(double heuristicCost) {
		this.heuristicCost = heuristicCost;
	}

	public double getEstimatedValue() {
		return estimatedValue;
	}

	public void setEstimatedValue() {
		this.estimatedValue = realCost + heuristicCost;
	}
	
	public boolean isEqualTo(Node node) {
		if(this.x == node.x && this.y == node.y && this.z == node.z)
			return true;
		return false;
	}
	
	public double getDistanceTo(Node target) {
		return Math.sqrt(Math.pow((target.x - x), 2) + Math.pow((target.y - y), 2) + Math.pow((target.z - z), 2));
	}
	
	public boolean isTarget(String target) {
		for(String i : targetInfo) {
			if(i.equals(target)) 
				return true;
		}
		return false;
	}

	@Override
	public int compareTo(Node obj) {
		if (this.estimatedValue < obj.estimatedValue)
			return -1;
		else if (this.estimatedValue == obj.estimatedValue)
			return 0;
		else
			return 1;
		
	}
	
	public boolean isSameFloor(Node target) {
		if (this.z != target.z)
			return false;
		return true;
	}
	
}
