import java.util.ArrayList;
import java.util.Collections;

public class MappingAlgo {
	private Node[] allNodes;
	private ArrayList<Node> open;
	private ArrayList<Node> closed;
	private Node start;
	private Node end;

	public MappingAlgo(Node[] nodes) {
		open = new ArrayList<Node>();
		closed = new ArrayList<Node>();
		allNodes = nodes;
		start = null;
		end = null;
	}

	public void setStartAndEnd(String startpos, String destination) {
		for(Node i : allNodes) {
			if (i.isTarget(startpos))
				start = i;
			if (i.isTarget(destination))
				end = i;
		}
	}
	
	public ArrayList<Node> getShortestPathToEnd(String startpos, String destination) {
		setStartAndEnd(startpos, destination);
		start.setHeuristicCost(start.getDistanceTo(end));
		open.add(start);
		if (!start.isSameFloor(end)) {
			String enterStair = "stair" + (int)start.getZ();
			String leaveStair = "stair" + (int)end.getZ();
			setStartAndEnd(startpos, enterStair);
			start.setHeuristicCost(start.getDistanceTo(end));
			generatePath();
			Node temp = end;
			setStartAndEnd(leaveStair, destination);
			start.setParent(temp);
			start.setHeuristicCost(start.getDistanceTo(end));
			open.clear();
			open.add(start);
			generatePath();
			return closed;
		}
		else {
			generatePath();
			return closed;
		}
	}

	private ArrayList<Node> generatePath() {
		while(!open.isEmpty()) {
			Collections.sort(open);

			// find the node with least estimated value f
			Node curNode = new Node(open.get(0));

			// pop the node off the list
			open.remove(0);

			System.out.println("current Node: (" + curNode.getX() + "," + curNode.getY() + ")");

			// set all adjacent successors' parent to picked node (max 8)
			ArrayList<Node> successors = setSuccessors(curNode);

			System.out.println("successor: " + successors.size());

			// Loop through all the successor
			for(Node i : successors) {

				// Check all the set successor to check, if found then break
				if(i.isEqualTo(end)) {
					closed.add(i);
					return closed;
				}

				System.out.println("Current successor: (" + i.getX() + ", " + i.getY() + ")");

				// set real cost of successors
				i.setRealCost(curNode.getRealCost() + i.getDistanceTo(curNode));
				System.out.println("real cost: " + i.getRealCost());

				// set heuristic value
				i.setHeuristicCost(i.getDistanceTo(end));
				System.out.println("h value: " + i.getHeuristicCost());

				// set estimated value
				i.setEstimatedValue();
				System.out.println("Estimated value: " + i.getEstimatedValue());


				// if the same position in the open list with lower f, then skip it
				if(openContains(i) != null && openContains(i).getEstimatedValue() <= i.getEstimatedValue()) {} // do nothing

				// if the same position in the closed list with lower f, then skip it
				else if(closedContains(i) != null && closedContains(i).getEstimatedValue() <= i.getEstimatedValue()) {} // do nothing

				// else add successors to the open list
				else
					open.add(i);
			}

			// push node to the closed list
			closed.add(curNode);

		}
		return closed;
	}

	private ArrayList<Node> setSuccessors(Node cur) {
		double x = cur.getX();
		double y = cur.getY();
		ArrayList<Node> result = new ArrayList<Node>();
		// Loop through all nodes and set each available successor's parent
		for(Node i : allNodes) {
			if(i.getX() == x && i.getY() == y) {} // do nothing
			else if((cur.getParent() != i) && (i.getX() <= x + 1) && (i.getX() >= x - 1) && (i.getY() <= y + 1) && (i.getY() >= y - 1)) {
				i.setParent(cur);
				System.out.println(getpos(i) + " set partent to " + getpos(cur));
				result.add(i);
			}
		}
		return result;
	}

	private Node openContains(Node n) {
		for(Node i : open) {
			if(i.isEqualTo(n))
				return i;
		}
		return null;
	}

	private Node closedContains(Node n) {
		for(Node i : closed) {
			if(i.isEqualTo(n))
				return i;
		}
		return null;
	}

	//	public String getStart() {
	//		return "(" + start.getX() + "," + start.getY() + ")";
	//	}
	//	public String getEnd() {
	//		return "(" + end.getX() + "," + end.getY() + ")";
	//	}
	
	public String getpos(Node n) {
		return "(" + n.getX() + ", " + n.getY() + ")";
	}
	
} // end of the class
