import java.util.ArrayList;

public class tester {

	public static void main(String[] args) {
		Node p1 = new Node(1, 1, 0);
		Node p2 = new Node(1, 4, 0);
		Node p3 = new Node(1, 2, 0);
		Node p4 = new Node(2, 2, 0);
		Node p5 = new Node(2, 3, 0);
		Node p6 = new Node(2, 4, 0);
		Node p7 = new Node(2, 8, 0);
		Node p8 = new Node(3, 4, 0);
		Node p9 = new Node(3, 6, 0);
		Node p10 = new Node(3, 7, 0);
		Node p11 = new Node(4, 4, 0);
		Node p12 = new Node(4, 5, 0);
		Node p13 = new Node(3, 6, 1);
		Node p14 = new Node(3, 7, 1);

		p1.addTargetInfo("start");
		p9.addTargetInfo("stair0");
		p13.addTargetInfo("stair1");
		p14.addTargetInfo("end");
		
		Node[] node = {p1, p2, p3, p4, p5, p6, p7, p8, p9, p10, p11, p12, p13, p14};
		
		MappingAlgo map = new MappingAlgo(node);
		ArrayList<Node> path = map.getShortestPathToEnd("start", "end");
		
		//print out path
		Node curNode = path.get(path.size() - 1);
		while(curNode != null) {
			System.out.println("(" + curNode.getX() + ", " + curNode.getY() + ", " + curNode.getZ() +")");
			curNode = curNode.getParent();
		}
		
	}

} // end of the class
