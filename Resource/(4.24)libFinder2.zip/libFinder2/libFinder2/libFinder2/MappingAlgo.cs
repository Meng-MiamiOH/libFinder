﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LibFinder2
{
    class MappingAlgo
    {
        private List<Node> allNodes;
        private List<Node> open;
        private List<Node> closed;
        private Node start;
        private Node end;
        private bool notFound = false;

        public MappingAlgo(List<Node> nodes)
        {
            open = new List<Node>();
            closed = new List<Node>();
            allNodes = nodes;
            start = null;
            end = null;
        }
        public void setStartAndEnd(String startpos, String destination)
        {
            foreach (Node i in allNodes)
            {
                if (i.isTarget(startpos))
                    start = i;
                if (i.isTarget(destination))
                    end = i;
            }
            if (end == null || start == null)
                notFound = true;
        }
        // Overide
        public void setStartAndEnd(Node startpos, String destination)
        {
            foreach (Node i in allNodes)
            {
                if (i.isTarget(destination))
                    end = i;
            }
            start = startpos;
            if (end == null || start == null)
                notFound = true;
        }
        // Overide
        public void setStartAndEnd(String startpos, Node destination)
        {
            foreach (Node i in allNodes)
            {
                if (i.isTarget(startpos))
                    start = i;
            }
            end = destination;
            if (end == null || start == null)
                notFound = true;
        }

        public Node[] getShortestPathToEnd(String startpos, String destination)
        {
            // initialize the notFound 
            notFound = false;
            // This will cause only two path for two seperate floors
            Node[] path = new Node[4];
            setStartAndEnd(startpos, destination);
            if (notFound)
                return null;
            if (!start.isSameFloor(end))
            {
                // Gnerate path from current position to the stair
                Node enterStair = findCloestStair(start);
                Node leaveStair = findPairStair(enterStair, end);
                setStartAndEnd(startpos, enterStair);
                start.heuristicCost = start.getDistanceTo(end);
                start.setEstimatedValue();
                open.Add(start);
                generatePath();
                path[(int)start.z] = end;
                closed.Clear();
                open.Clear();

                //Generate path from stair to the end destination
                setStartAndEnd(leaveStair, destination);
                start.heuristicCost = start.getDistanceTo(end);
                start.setEstimatedValue();
                open.Add(start);
                generatePath();
                path[(int)start.z] = end;
                return path;
            }
            else
            {
                start.heuristicCost = start.getDistanceTo(end);
                start.setEstimatedValue(); // every time when set heuristicCost ,the estimated value must be updated
                open.Add(start);
                generatePath();
                path[(int)start.z] = end;
                return path;
            }
        }

        private List<Node> generatePath()
        {
            while (open.Count != 0)
            {
                open.Sort(delegate (Node x, Node y) { return x.estimatedValue.CompareTo(y.estimatedValue); });

                // find the node with least estimated value f
                Node curNode = new Node(open[0]);

                // pop the node off the list
                open.RemoveAt(0);

                Console.WriteLine("current Node: (" + curNode.x + "," + curNode.y + ")");

                // set all adjacent successors' parent to picked node (max 8)
                List<Node> successors = setSuccessors(curNode);

                Console.WriteLine("successor: " + successors.Count);

                // Loop through all the successor
                foreach (Node i in successors)
                {

                    // Check all the set successor to check, if found then break
                    if (i.isEqualTo(end))
                    {
                        closed.Add(i);
                        return closed;
                    }

                    Console.WriteLine("Current successor: (" + i.x + ", " + i.y + ")");

                    // set real cost of successors
                    i.realCost = curNode.realCost + i.getDistanceTo(curNode);
                    Console.WriteLine("real cost: " + i.realCost);

                    // set heuristic value
                    i.heuristicCost = i.getDistanceTo(end);
                    Console.WriteLine("h value: " + i.heuristicCost);

                    // set estimated value
                    i.setEstimatedValue();
                    Console.WriteLine("Estimated value: " + i.estimatedValue);


                    // if the same position in the open list with lower f, then skip it
                    if (openContains(i) != null && openContains(i).estimatedValue <= i.estimatedValue) { } // do nothing

                    // if the same position in the closed list with lower f, then skip it
                    else if (closedContains(i) != null && closedContains(i).estimatedValue <= i.estimatedValue) { } // do nothing

                    // else add successors to the open list
                    else
                        open.Add(i);
                }

                // push node to the closed list
                closed.Add(curNode);

            }
            return closed;
        }

        private List<Node> setSuccessors(Node cur)
        {
            double x = cur.x;
            double y = cur.y;
            List<Node> result = new List<Node>();
            // Loop through all nodes and set each available successor's parent
            foreach (Node i in allNodes)
            {
                if (i.x == x && i.y == y) { } // do nothing
                else if ((cur.parent != i) && (i.x < x + 5.0728) && (i.x > x - 5.0728) && (i.y < y + 5.0728) && (i.y > y - 5.0728) && (i.z == cur.z))
                {
                    i.parent = cur;
                    Console.WriteLine(getpos(i) + " set partent to " + getpos(cur));
                    result.Add(i);
                }
            }
            return result;
        }

        private Node openContains(Node n)
        {
            foreach (Node i in open)
            {
                if (i.isEqualTo(n))
                    return i;
            }
            return null;
        }

        private Node closedContains(Node n)
        {
            foreach (Node i in closed)
            {
                if (i.isEqualTo(n))
                    return i;
            }
            return null;
        }

        //	public String getStart() {
        //		return "(" + start.x + "," + start.y + ")";
        //	}
        //	public String getEnd() {
        //		return "(" + end.x + "," + end.y + ")";
        //	}

        public String getpos(Node n)
        {
            return "(" + n.x + ", " + n.y + ")";
        }

        private Node findCloestStair(Node pos)
        {
            double minDistance = 100000;
            Node stair = new Node(0, 0, 0);
            foreach (Node n in allNodes)
            {
                if (n.isSameFloor(pos))
                {
                    if (n.targetInfo.Contains("STAIRS A") || n.targetInfo.Contains("STAIRS B") || n.targetInfo.Contains("STAIRS C") || n.targetInfo.Contains("STAIRS D"))
                    {
                        if ((n.getDistanceTo(pos) < minDistance))
                        {
                            minDistance = n.getDistanceTo(pos);
                            stair = n;
                        }
                    }
                }
            }
            return stair;
        }

        private Node findPairStair(Node enterStair, Node destination)
        {
            Node stair = new Node(0, 0, 0);
            foreach (Node nod in allNodes)
            {
                if (nod.isSameFloor(destination))
                {
                    if (nod.targetInfo.Contains(enterStair.targetInfo[0]))
                    {
                        stair = nod;
                    }
                }
            }
            return stair;
        }

    }
}
