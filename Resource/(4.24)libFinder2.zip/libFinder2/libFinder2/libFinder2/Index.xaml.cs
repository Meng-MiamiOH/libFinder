﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Xamarin.Essentials;
using Xamarin.Forms;
using Xamarin.Forms.Xaml;
using SkiaSharp;
using SkiaSharp.Views.Forms;
using System.ComponentModel;
using LibFinder2;

namespace libFinder2
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class Index : ContentPage
    {
        private string endPoint;
        private SKPath path = new SKPath();
        private SKImageInfo info;
        private SKSurface surface;
        private SKCanvas canvas;
        private SKCanvasView ViewCanvas;
        private int floorIndex = 1;
        private Node[] mappingPaths;
        private MappingAlgo mapping;
        private SKPaint blackFill = new SKPaint
        {
            Style = SKPaintStyle.Stroke,
            Color = SKColors.Red,
            StrokeWidth = 10,
            StrokeCap = SKStrokeCap.Round,
            IsAntialias = true
        };


        public Index()
        {
            InitializeComponent();
            OpenMap();
        }

        private void drawPathLine()
        {
            path.Reset();
            if (mappingPaths == null)
            {
                first.IsEnabled = true;
                second.IsEnabled = true;
                third.IsEnabled = true;
                basement.IsEnabled = true;
                return;
            }
            
            // disable all floor buttons that is not within the path
            first.IsEnabled = mappingPaths[1] == null? false: true;
            second.IsEnabled = mappingPaths[2] == null ? false : true;
            third.IsEnabled = mappingPaths[3] == null ? false : true;
            basement.IsEnabled = mappingPaths[0] == null ? false : true;


            if (floorIndex == 0 && mappingPaths[floorIndex] != null)
            {
                Node curNode = mappingPaths[floorIndex];
                path.MoveTo(((float)curNode.x * 0.00342437f - 0.0603714f) * info.Width, ((float)curNode.y * -0.00432437f + 1.040018029f) * info.Height);
                curNode = curNode.parent;
                while (curNode != null)
                {
                    path.LineTo(((float)curNode.x * 0.00342437f - 0.0603714f) * info.Width, ((float)curNode.y * -0.00432437f + 1.040018029f) * info.Height);
                    curNode = curNode.parent;
                }
            }
            if (floorIndex == 1 && mappingPaths[floorIndex] != null)
            {
                Node curNode = mappingPaths[floorIndex];
                path.MoveTo(((float)curNode.x * 0.00331191f - 0.04510335f) * info.Width, ((float)curNode.y * -0.00585355f + 1.20348595f) * info.Height);
                curNode = curNode.parent;
                while (curNode != null)
                {
                    path.LineTo(((float)curNode.x * 0.00331191f - 0.04510335f) * info.Width, ((float)curNode.y * -0.00585355f + 1.20348595f) * info.Height);
                    curNode = curNode.parent;
                }
            }
            if (floorIndex == 2 && mappingPaths[floorIndex] != null)
            {
                Node curNode = mappingPaths[floorIndex];
                path.MoveTo(((float)curNode.x * 0.00344023f - 0.05071725f) * info.Width, ((float)curNode.y * -0.0061366f + 1.18893035844f) * info.Height);
                curNode = curNode.parent;
                while (curNode != null)
                {
                    path.LineTo(((float)curNode.x * 0.00344023f - 0.05071725f) * info.Width, ((float)curNode.y * -0.0061366f + 1.18893035844f) * info.Height);
                    curNode = curNode.parent;
                }
            }
            if (floorIndex == 3 && mappingPaths[floorIndex] != null)
            {
                Node curNode = mappingPaths[floorIndex];
                path.MoveTo(((float)curNode.x * 0.005216532395f - 0.04654246998f) * info.Width, ((float)curNode.y * -0.0094761860666f + 1.1735700589553f) * info.Height);
                curNode = curNode.parent;
                while (curNode != null)
                {
                    path.LineTo(((float)curNode.x * 0.005216532395f - 0.04654246998f) * info.Width, ((float)curNode.y * -0.0094761860666f + 1.1735700589553f) * info.Height);
                    curNode = curNode.parent;
                }
            }
        }

        private void CanvasView_PaintSurface(object sender, SKPaintSurfaceEventArgs e)
        {
            info = e.Info;
            surface = e.Surface;
            canvas = surface.Canvas;
            ViewCanvas = (SKCanvasView)sender;

            canvas.Clear(SKColors.White);

            SKBitmap map = BitmapExtensions.LoadBitmapResource(GetType(), "libFinder2.map"+floorIndex+".png");
            if (endPoint != null && endPoint.Length != 0)
            {
                mappingPaths = mapping.getShortestPathToEnd(endPoint, "R127");
                if (mappingPaths == null)
                {
                    DisplayAlert("Error: not found", "The call number or place entered is not found", "OK");
                }
            }
            else
                mappingPaths = null;
            //mappingPaths = mapping.getShortestPathToEnd("R305", "R319");
            drawPathLine();

            canvas.DrawBitmap(map, info.Rect, BitmapStretch.Uniform);
            canvas.DrawPath(path, blackFill);
        }

        private void OpenMap()
        {
            List<Node> node = new List<Node>();

            //First read the map data 
            string[] lines = File.ReadAllLines("MapData.txt");
            foreach (string line in lines)
            {
                string[] data = line.Trim().Split('\t');
                double xPos = Double.Parse(data[1]);
                double yPos = Double.Parse(data[2]);
                double zPos = Double.Parse(data[3]);
                Node n = new Node(xPos, yPos, zPos);
                n.addTargetInfo(data[0]);
                node.Add(n);

                //Console.WriteLine("(" + xPos + ", " + yPos + ", " + zPos + ") " + data[0]);
            }
            mapping = new MappingAlgo(node);
        }

        private void first_Clicked(object sender, EventArgs e)
        {
            //map.Source = "firstFloor.jpg";
            Preferences.Set("image", "firstFloor.jpg");
            first.BackgroundColor = Xamarin.Forms.Color.White;
            first.TextColor = Xamarin.Forms.Color.FromRgb(195, 20, 45);
            second.BackgroundColor = Xamarin.Forms.Color.FromRgb(195, 20, 45);
            second.TextColor = Xamarin.Forms.Color.White;
            third.BackgroundColor = Xamarin.Forms.Color.FromRgb(195, 20, 45);
            third.TextColor = Xamarin.Forms.Color.White;
            basement.BackgroundColor = Xamarin.Forms.Color.FromRgb(195, 20, 45);
            basement.TextColor = Xamarin.Forms.Color.White;
            floorIndex = 1;
            ViewCanvas.InvalidateSurface();
        }

        private void second_Clicked(object sender, EventArgs e)
        {
            //map.Source = "secondFloor.jpg";
            Preferences.Set("image", "secondFloor.jpg");
            second.BackgroundColor = Xamarin.Forms.Color.White;
            second.TextColor = Xamarin.Forms.Color.FromRgb(195, 20, 45);
            first.BackgroundColor = Xamarin.Forms.Color.FromRgb(195, 20, 45);
            first.TextColor = Xamarin.Forms.Color.White;
            third.BackgroundColor = Xamarin.Forms.Color.FromRgb(195, 20, 45);
            third.TextColor = Xamarin.Forms.Color.White;
            basement.BackgroundColor = Xamarin.Forms.Color.FromRgb(195, 20, 45);
            basement.TextColor = Xamarin.Forms.Color.White;
            floorIndex = 2;
            ViewCanvas.InvalidateSurface();
        }

        private void third_Clicked(object sender, EventArgs e)
        {
           // map.Source = "thirdFloor.jpg";
            Preferences.Set("image", "thirdFloor.jpg");
            third.BackgroundColor = Xamarin.Forms.Color.White;
            third.TextColor = Xamarin.Forms.Color.FromRgb(195, 20, 45);
            first.BackgroundColor = Xamarin.Forms.Color.FromRgb(195, 20, 45);
            first.TextColor = Xamarin.Forms.Color.White;
            second.BackgroundColor = Xamarin.Forms.Color.FromRgb(195, 20, 45);
            second.TextColor = Xamarin.Forms.Color.White;
            basement.BackgroundColor = Xamarin.Forms.Color.FromRgb(195, 20, 45);
            basement.TextColor = Xamarin.Forms.Color.White;
            floorIndex = 3;
            ViewCanvas.InvalidateSurface();
        }

        private void basement_Clicked(object sender, EventArgs e)
        {
            //map.Source = "basement.jpg";
            Preferences.Set("image", "basement.jpg");
            basement.BackgroundColor = Xamarin.Forms.Color.White;
            basement.TextColor = Xamarin.Forms.Color.FromRgb(195, 20, 45);
            first.BackgroundColor = Xamarin.Forms.Color.FromRgb(195, 20, 45);
            first.TextColor = Xamarin.Forms.Color.White;
            second.BackgroundColor = Xamarin.Forms.Color.FromRgb(195, 20, 45);
            second.TextColor = Xamarin.Forms.Color.White;
            third.BackgroundColor = Xamarin.Forms.Color.FromRgb(195, 20, 45);
            third.TextColor = Xamarin.Forms.Color.White;
            floorIndex = 0;
            ViewCanvas.InvalidateSurface();
        }

        private async void account_Clicked(object sender, EventArgs e)
        {
            ContentPage add = new Account();
            await Navigation.PushAsync(add, true);
        }

        public static string val;
        //use for seperate each line, splite by ";"
        static string[] array;
        //use for seperate each element in each line splite by ","
        static string[] secondArray;
        // third array, use for seperate range of call numbers by " "
        static string[] thirdArray;
        private void Start_Clicked(object sender, EventArgs e)
        {
            if (search.Text == null || search.Text == "First part of Call num or place name" || search.Text.Length == 0)
            {
                //test.Text = "Please enter the call no or find target in quick search";
                endPoint = null;
                ViewCanvas.InvalidateSurface();
            }
            else
            {
                try
                {
                    string line = "";
                    using (StreamReader sr = new StreamReader("search data example.txt"))
                    {
                        line = sr.ReadToEnd();
                        test.Text = line;
                    }
                    array = line.Split(';');
                }
                catch (IOException ex)
                {
                    test.Text = ex.Message;
                }

                val = search.Text;

                if (val.Length > 2) // search string cannto less than 2 bytes
                {
                    // seperate user input to two seperate parts
                    string topTwoLetter = val.Substring(0, 2);
                    string restLetter = val.Substring(2, val.Length - 2);

                    // go through search function
                    string ShelfName = Search(topTwoLetter, restLetter);

                    //print out result
                    //Console.Write("Your book is at : " + ShelfName);
                    //test.Text = "Your book is at : " + topTwoLetter + restLetter + "\n" + array.ToString();
                    test.Text = "Your book is at : " + ShelfName;
                    if (ShelfName.Equals("Not Found"))
                    {
                        endPoint = search.Text;
                    }
                    else
                    {
                        endPoint = ShelfName;
                    }
                    ViewCanvas.InvalidateSurface();
                }
            }
        }

        // search bool from top two letter of call number
        private static string Search(string topTwoLetter, string restLetter)
        {
            for (int i = 0; i < array.Length; i++)
            {
                secondArray = array[i].Split(',');
                for (int j = 1; j < secondArray.Length; j++)
                {
                    //check top two letter of call number is equal to Bookshelf inofrmation or not 
                    if (topTwoLetter.CompareTo(secondArray[j].Substring(0, 2)) == 0)
                    {
                        //check weather the call number is in the correct bookshelf range; 
                        //for example B 0 358 which means this bookshefs has category B from 0 to 358
                        if (secondArray[j].Length > 2)
                        {
                            thirdArray = secondArray[j].Split(' ');
                            double numberTwo = Convert.ToDouble(thirdArray[1]);
                            double numberThree = Convert.ToDouble(thirdArray[2]);
                            double restNumber = Convert.ToDouble(restLetter);
                            if (numberTwo < restNumber && numberThree >= restNumber)
                            {
                                return secondArray[0];
                            }
                        }
                        // if the range only has letter no range; 
                        //for example which means this bookshefs has category BC, BD, BE in the same bookshelf
                        if (secondArray[j].Length == 2)
                        {
                            return secondArray[0];
                        }
                    }
                }
            }
            return "Not Found";
        }

        private void QuickSearchPicker_PropertyChanged(object sender, System.ComponentModel.PropertyChangedEventArgs e)
        {
            var picker = (Picker)sender;
            int selectedIndex = picker.SelectedIndex;
            if (selectedIndex != -1)
            {
                search.Text = (string)picker.ItemsSource[selectedIndex];
            }
        }

        private async void Map_Clicked(object sender, EventArgs e)
        {
            ContentPage pic = new PicturePage();
            await Navigation.PushAsync(pic, true);
        }
    }
}