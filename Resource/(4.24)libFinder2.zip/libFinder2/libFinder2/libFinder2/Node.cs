﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LibFinder2
{
    class Node
    {
        public double x { get; set; }
        public double y { get; set; }
        public double z { get; set; }
        public List<String> targetInfo { get; } // one point could has multiple items or no information
        public Node parent { get; set; }
        public double realCost { get; set; }
        public double heuristicCost { get; set; }
        public double estimatedValue { get; set; }

        // constructor
        public Node(double x, double y, double z)
        {
            this.x = x;
            this.y = y;
            this.z = z;
            targetInfo = new List<String>();
            realCost = 0;
            heuristicCost = 0;
            estimatedValue = 0;
            parent = null;
        }

        // copy constructor
        public Node(Node obj)
        {
            this.x = obj.x;
            this.y = obj.y;
            this.z = obj.z;
            targetInfo = obj.targetInfo;
            realCost = obj.realCost;
            heuristicCost = obj.heuristicCost;
            estimatedValue = obj.estimatedValue;
            parent = obj.parent;
        }

        public void addTargetInfo(String str)
        {
            this.targetInfo.Add(str);
        }

        public void setEstimatedValue()
        {
            this.estimatedValue = realCost + heuristicCost;
        }

        public bool isEqualTo(Node node)
        {
            if (this.x == node.x && this.y == node.y && this.z == node.z)
                return true;
            return false;
        }

        public double getDistanceTo(Node target)
        {
            return Math.Sqrt(Math.Pow((target.x - x), 2) + Math.Pow((target.y - y), 2));
        }

        public bool isTarget(String target)
        {
            foreach (String i in targetInfo)
            {
                if (i.Equals(target))
                    return true;
            }
            return false;
        }

        public bool isSameFloor(Node target)
        {
            if (this.z != target.z)
                return false;
            return true;
        }
    }
}
